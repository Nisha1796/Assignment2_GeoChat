package com.zv.geochat.ui.adapter;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.zv.geochat.R;
import com.zv.geochat.model.ChatMessage;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import co.dift.ui.SwipeToAction;


public class ChatMessagesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<ChatMessage> items;


    /** References to the views for each data item **/
    public class ChatMessageViewHolder extends SwipeToAction.ViewHolder<ChatMessage> {
        public TextView userName;
        public TextView chatMessageBody;
        public ImageView imageView;
        public TextView  msgDate;
        public TextView msgID;

        public ChatMessageViewHolder(View v) {
            super(v);

            userName = (TextView) v.findViewById(R.id.userName);
            chatMessageBody = (TextView) v.findViewById(R.id.body);
            imageView = (ImageView) v.findViewById(R.id.image);
            msgDate = (TextView) v.findViewById(R.id.Date);
            msgID = (TextView) v.findViewById(R.id.ID);
        }
    }

    /** Constructor **/
    public ChatMessagesAdapter(List<ChatMessage> items) {
        this.items = items;
    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_view, parent, false);

        return new ChatMessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ChatMessage item = items.get(position);
        ChatMessageViewHolder vh = (ChatMessageViewHolder) holder;
        vh.userName.setText(item.getUserName());
        vh.chatMessageBody.setText(item.getBody());
        vh.data = item;
        if(item.getMsgDate()!=null) {
            Date date = new Date();
            date.setTime(Long.parseLong(item.getMsgDate()));
            DateFormat compareDate = new SimpleDateFormat("yyyyMMdd");
            if(compareDate.format(date).equals(compareDate.format(new Date())))
            {
                Log.v("Before", "Today "+ item.getBody());
                DateFormat dateFormattoday = new SimpleDateFormat("HH:mm:ss");
                vh.msgDate.setText(dateFormattoday.format(date));
            }
            else
            {
                DateFormat dateFormate = new SimpleDateFormat("MM/dd/yyyy");
                vh.msgDate.setText(dateFormate.format(date));
//                vh.msgDate.setText("2/02/2021");

            }

        }
        vh.msgID.setText(item.getId());



    }
    }
