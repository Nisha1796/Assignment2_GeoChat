package com.zv.geochat.model;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatMessage {
    private String id;
    private String userName;
    private String body;
    private String  msgDate;


    public ChatMessage() {
        Date date = new Date();
        String.valueOf(date.getTime());

    }
    public String getCurrentDate()
    {
        Date date = new Date();
        return String.valueOf(date.getTime());
    }

    public String getTime() {
        DateFormat dateFormat = new SimpleDateFormat("HH:mm");
        Date time = new Date();

        return dateFormat.format(time);
    }

    public ChatMessage(String userName, String body) {
        this.userName = userName;
        this.body = body;

    }

    public ChatMessage(String id, String userName, String body) {
        this.id = id;
        this.userName = userName;
        this.body = body;

    }


    public String getUserName() {
        return userName;
    }

    public String getBody() {
        return body;
    }

    public String getId() {
        return id;
    }

    public String getMsgDate() { return this.msgDate; }
    public String getDateTime() { return msgDate; }

    public void setId(String id) {
        this.id = id;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public void setMsgDate(String  msgDate){ this.msgDate = msgDate; }

    @Override
    public String toString() {
        return "ChatMessage{" +
                "id='" + id + '\'' +
                ", userName='" + userName + '\'' +
                ", body='" + body + '\'' +
                ",msgDate=" + msgDate + '\'' +
                '}';
    }



}
